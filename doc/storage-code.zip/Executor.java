package com.azure.storage;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Executor {
  public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
    String accountName = "STORAGE-ACCOUNT-NAME";
    String accountKey = "STORAGE-ACCOUNT-KEY";
    Utilities utilities = new Utilities(accountName, accountKey);
    createContainer (utilities, "CONTAINER-NAME");
  }
  
   static void listExistingContainers(Utilities utilities) {
    utilities.listExistingContainers();
  }

  static void createContainer(Utilities utilities, String containerName) {
    utilities.createContainer(containerName);
  }

  static void deleteContainer(Utilities utilities, String containerName) {
	    utilities.deleteContainer(containerName);
	  }
  
  static void listExistingBlobs(Utilities utilities, String containerName) {
    utilities.listExistingBlobs(containerName);
  }

  static void uploadBlob(Utilities utilities, String localPath, String blobName, String containerName) {
    utilities.uploadBlob(localPath, blobName, containerName);
  }

  static void uploadBlobWithMetadata(Utilities utilities, String localPath, String blobName, String containerName) {
    Map<String, String> metadata = new HashMap<>();
    metadata.put("Project", "HRMS");
    utilities.uploadBlobWithMetadata(localPath, blobName, containerName, metadata);
  }

  static void addMetadataToExistingBlob(Utilities utilities, String blobName, String containerName) {
	    Map<String, String> metadata = new HashMap<>();
	    metadata.put("Owner", "Ahmad");
	    utilities.addMetadataToExistingBlob(blobName, containerName, metadata);
  }
  
  static void downloadBlob(Utilities utilities, String blobName, String containerName, String localPath) {
    utilities.downloadBlob(blobName, containerName, localPath);
  }

  static void getAccessUrl(Utilities utilities, String blobName, String containerName) throws MalformedURLException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
    utilities.sharedAccessForBlob(blobName, containerName, 5);
  }

  static void getUrlData(Utilities utilities, URL url) throws IOException {
    InputStream inputStream = utilities.getUrlData(url);
    Scanner s = new Scanner(inputStream).useDelimiter("\\A");
    String result = s.hasNext() ? s.next() : "";
    System.out.println(result);
  }
}
