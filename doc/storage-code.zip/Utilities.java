package com.azure.storage;

import com.azure.storage.blob.BlobClient;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobErrorCode;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.BlobStorageException;
import com.azure.storage.common.StorageSharedKeyCredential;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class Utilities {

  private final BlobServiceClient storageClient;
  private final String accountkey;

  public Utilities(String accountName, String accountKey) {
    this.accountkey = accountKey;
    String endpoint = String.format(Locale.ROOT, "https://%s.blob.core.windows.net", accountName);
    storageClient = new BlobServiceClientBuilder().endpoint(endpoint).credential(new StorageSharedKeyCredential(accountName, accountKey)).buildClient();
  }

  public void listExistingContainers() {
    List<String> containerNames = new ArrayList<>();
    storageClient.listBlobContainers()
            .forEach(containerItem -> {
              containerNames.add(containerItem.getName());
            });
    if (containerNames.size() > 0) {
      containerNames.forEach(System.out::println);
    } else {
      System.out.printf("No containers are present in this storage account %s", storageClient.getAccountName());
    }
  }

  public void createContainer(String containerName) {
    storageClient.createBlobContainer(containerName);
    System.out.printf("Container %s created successfully", containerName);
  }

  public void deleteContainer(String containerName) {
    try {
      BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
      blobContainerClient.delete();
      System.out.printf("Delete completed%n");
    } catch (BlobStorageException error) {
      if (error.getErrorCode().equals(BlobErrorCode.CONTAINER_NOT_FOUND)) {
        System.out.printf("Delete failed. Container was not found %n");
      }
    }
  }

  public void listExistingBlobs(String containerName) {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    List<String> blobNames = new ArrayList<>();
    // List the blob(s) in the container.
    for (BlobItem blobItem : blobContainerClient.listBlobs()) {
      blobNames.add(blobItem.getName());
    }
    if (blobNames.size() > 0) {
      blobNames.forEach(System.out::println);
    } else {
      System.out.printf("No blobs are present in the container %s", containerName);
    }
  }

  public void uploadBlob(String localBlobPath, String blobName, String containerName) {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    // Get a reference to a blob
    BlobClient blobClient = blobContainerClient.getBlobClient(blobName);
    System.out.println("\nUploading to Blob storage as blob:\n\t" + blobClient.getBlobUrl());
    blobClient.uploadFromFile(localBlobPath);
  }

  public void addMetadataToExistingBlob(String blobName, String containerName, Map<String, String> metadata) {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    // Get a reference to a blob
    BlobClient blobClient = blobContainerClient.getBlobClient(blobName);
    blobClient.setMetadata(metadata);
    System.out.printf("Added metadata to existing blob %s successfully", blobName);
  }

  public void uploadBlobWithMetadata(String localBlobPath, String blobName, String containerName, Map<String, String> metadata) {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    // Get a reference to a blob
    BlobClient blobClient = blobContainerClient.getBlobClient(blobName);
    System.out.println("\nUploading to Blob storage as blob:\n\t" + blobClient.getBlobUrl());
    blobClient.uploadFromFile(localBlobPath);
    blobClient.setMetadata(metadata);
  }

  public void downloadBlob(String blobName, String containerName, String path) {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    // Get a reference to a blob
    BlobClient blobClient = blobContainerClient.getBlobClient(blobName);
    blobClient.downloadToFile(path);
  }


  public void sharedAccessForBlob(String blobName, String containerName, int numberOfDays) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException, MalformedURLException {
    BlobContainerClient blobContainerClient = storageClient.getBlobContainerClient(containerName);
    // Get a reference to a blob
    BlobClient blobClient = blobContainerClient.getBlobClient(blobName);
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
    fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date());
    String start = fmt.format(cal.getTime());
    cal.add(Calendar.DATE, numberOfDays);
    String expiry = fmt.format(cal.getTime());
    String StorageAccountName = storageClient.getAccountName();
    String StorageAccountKey = accountkey;
    String apiVersion = "2019-07-07";
    String resource = "sco";
    String permissions = "rwdlac";
    String service = "b";
    String stringToSign = StorageAccountName + "\n" +
            permissions + "\n" +  // signed permissions
            service + "\n" + // signed service
            resource + "\n" + // signed resource type
            start + "\n" + // signed start
            expiry + "\n" + // signed expiry
            "\n" +  // signed IP
            "https\n" + // signed Protocol
            apiVersion + "\n"; // signed version

    SecretKeySpec secretKey = new SecretKeySpec(Base64.getDecoder().decode(StorageAccountKey), "HmacSHA256");
    Mac sha256HMAC = Mac.getInstance("HmacSHA256");
    sha256HMAC.init(secretKey);
    String signature = Base64.getEncoder().encodeToString(sha256HMAC.doFinal(stringToSign.getBytes("UTF-8")));
    String sasToken = "sv=" + apiVersion +
            "&ss=" + service +
            "&srt=" + resource +
            "&sp=" + permissions +
            "&se=" + URLEncoder.encode(expiry, "UTF-8") +
            "&st=" + URLEncoder.encode(start, "UTF-8") +
            "&spr=https" +
            "&sig=" + URLEncoder.encode(signature, "UTF-8");
    String resourceUrl = blobClient.getBlobUrl(); //  blob url
    URL url = new URL(resourceUrl + "?" + sasToken);
    System.out.println(url.toString());
  }

  public InputStream getUrlData(URL url) throws IOException {
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    return connection.getInputStream();

  }
}